https://fortunate-decimal-730.notion.site/Youpk-Aosp10-ead82bb5990c4574a9fc0e5d899beaa1

https://bbs.kanxue.com/thread-282634.htm